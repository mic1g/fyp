%Centralized operation
    lb = [0; 5; 0; 7; 0; 10];
    ub = [20, 15, 25, 18, 30, 25];
    alpha1 = 0.015;
    alpha2 = 0.038;
    beta1 = -0.008;
    beta2 = 0.8;
    alpha3 = 0.008;
    alpha4 = 0.047;
    beta3 = -0.014;
    beta4 = 0.5;
    alpha5 = 0.011;
    alpha6 = 0.056;
    beta5 = -0.009;
    beta6 = 0.4;

    x = solveoptimization_centralized(lb, ub, alpha1, alpha2, beta1, beta2, alpha3, alpha4, beta3, beta4, alpha5, alpha6, beta5, beta6);
    p1 = x(1);
    d1 = x(2);
    p2 = x(3);
    d2 = x(4);
    p3 = x(5);
    d3 = x(6);
    
