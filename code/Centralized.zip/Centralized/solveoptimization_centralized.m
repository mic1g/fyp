function x = solveoptimization_centralized(lb,ub,alpha1,alpha2,beta1,beta2,alpha3,alpha4,beta3,beta4,alpha5,alpha6,beta5,beta6)

objfun = @(x)alpha1*x(1)^2 + alpha2*x(1) - beta1*x(2)^2 - beta2*x(2) + alpha3*x(3)^2 + alpha4*x(3) - beta3*x(4)^2 - beta4*x(4) + alpha5*x(5)^2 + alpha6*x(5) - beta5*x(6)^2 - beta6*x(6);
x = fmincon(objfun,[0;0;0;0;0;0],[],[],[1,-1,1,-1,1,-1],[0],lb,ub);
end